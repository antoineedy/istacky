from istacky.BlendedImage import BlendedImage
